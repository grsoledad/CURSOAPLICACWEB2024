-- Active: 1733870745895@@127.0.0.1@3306@colegio
USE colegio;

-- Control de auditoría para la tabla cursos
DROP TABLE IF EXISTS control_auditoria;
CREATE TABLE control_auditoria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tabla VARCHAR(50) NOT NULL,
    evento ENUM('INSERT', 'DELETE', 'UPDATE') NOT NULL,
    id_registro INT,
    fecha DATE,
    hora TIME,
    usuario VARCHAR(50)
);

-- CURSOS DELETE
DROP TRIGGER IF EXISTS TR_cursos_delete;
CREATE TRIGGER TR_cursos_delete
AFTER DELETE ON cursos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria 
        (tabla, evento, id_registro, fecha, hora, usuario)
    VALUES
        ('cursos', 'DELETE', OLD.id, CURDATE(), CURTIME(), USER());
END;

DELETE FROM cursos WHERE id = 2;

SELECT * FROM cursos;
SELECT * FROM control_auditoria;

-- CURSOS INSERT
DROP TRIGGER IF EXISTS TR_cursos_insert;
CREATE TRIGGER TR_cursos_insert
AFTER INSERT ON cursos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria 
        (tabla, evento, id_registro, fecha, hora, usuario)
    VALUES
        ('cursos', 'INSERT', NEW.id, CURDATE(), CURTIME(), USER());
END;
INSERT INTO cursos (titulo, profesor, dia, turno)
VALUES ('Marketing', 'Joseph Navarro', 'LUNES', 'MAÑANA'),
       ('Inteligencia Artificial', 'Leandro Vasques', 'VIERNES', 'NOCHE');
SELECT * FROM cursos;
SELECT * FROM control_auditoria;

-- CURSOS UPDATE
DROP TRIGGER IF EXISTS TR_cursos_update;
CREATE TRIGGER TR_cursos_update
AFTER UPDATE ON cursos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria 
        (tabla, evento, id_registro, fecha, hora, usuario)
    VALUES
        ('cursos', 'UPDATE', OLD.id, CURDATE(), CURTIME(), USER());
END;

UPDATE cursos SET titulo = 'POO' WHERE id = 1;
SELECT * FROM cursos;
SELECT * FROM control_auditoria;

-- Control de auditoría para la tabla alumnos
DROP TABLE IF EXISTS control_auditoria;
CREATE TABLE control_auditoria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tabla VARCHAR(50) NOT NULL,
    evento ENUM('INSERT', 'DELETE', 'UPDATE') NOT NULL,
    id_registro INT,
    fecha DATE,
    hora TIME,
    usuario VARCHAR(50)
);
-- INSERT ALUMNOS
DROP TRIGGER IF EXISTS TR_alumnos_insert;
CREATE TRIGGER TR_alumnos_insert
AFTER INSERT ON alumnos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria 
        (tabla, evento, id_registro, fecha, hora, usuario)
    VALUES
        ('alumnos', 'INSERT', NEW.id, CURDATE(), CURTIME(), USER());
END;
INSERT INTO alumnos(nombre, apellido, edad, id_curso)
VALUES ('UMMA', 'VERON', 24, 4), 
       ('MARTINA', 'LAMAESTRE', 23, 4);
SELECT * FROM alumnos;
SELECT * FROM control_auditoria;

-- DELETE ALUMNOS
DROP TRIGGER IF EXISTS TR_alumnos_delete;
CREATE TRIGGER TR_alumnos_delete
AFTER DELETE ON alumnos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria 
        (tabla, evento, id_registro, fecha, hora, usuario)
    VALUES
        ('alumnos', 'DELETE', OLD.id, CURDATE(), CURTIME(), USER());
END;

DELETE FROM alumnos WHERE id = 5;
SELECT * FROM alumnos;
SELECT * FROM control_auditoria;

-- ALUMNOS UPDATE
DROP TRIGGER IF EXISTS TR_alumnos_update;
CREATE TRIGGER TR_alumnos_update
AFTER UPDATE ON alumnos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria 
        (tabla, evento, id_registro, fecha, hora, usuario)
    VALUES
        ('alumnos', 'UPDATE', OLD.id, CURDATE(), CURTIME(), USER());
END;
SELECT * FROM alumnos;
UPDATE alumnos SET apellido = 'FERNANDEZ' WHERE id = 1;
SELECT * FROM alumnos;
SELECT * FROM control_auditoria;


-- DELETE FISICO Y TABLAS ALTERNATIVAS
DROP TABLE IF EXISTS cursos_borrados;
CREATE TABLE cursos_borrados (
    id INT,
    titulo VARCHAR(50),
    profesor VARCHAR(50),
    dia ENUM('LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES'),
    turno ENUM('MAÑANA', 'TARDE', 'NOCHE'),
    fecha_borrado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

DROP TRIGGER IF EXISTS registrar_cursos_borrados;
CREATE TRIGGER registrar_cursos_borrados
BEFORE DELETE ON cursos
FOR EACH ROW
BEGIN    
    INSERT INTO cursos_borrados (id, titulo, profesor, dia, turno, fecha_borrado)
    VALUES (OLD.id, OLD.titulo, OLD.profesor, OLD.dia, OLD.turno, NOW());
END;

INSERT INTO cursos (titulo, profesor, dia, turno) 
VALUES ('LOGICA', 'Juan Pérez', 'LUNES', 'MAÑANA');

SELECT * FROM cursos;
DELETE FROM cursos WHERE id = 6;
SELECT * FROM cursos_borrados;

DROP TABLE IF EXISTS alumnos_borrados;
CREATE TABLE alumnos_borrados (
    id INT,
    nombre VARCHAR(50),
    apellido VARCHAR(50),
    edad INT NOT NULL CHECK (edad >= 18 AND edad <= 120),
    id_curso INT NOT NULL,
    FOREIGN KEY (id_curso) REFERENCES cursos(id),
    fecha_borrado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
DROP TRIGGER IF EXISTS registrar_alumnos_borrados;
CREATE TRIGGER registrar_alumnos_borrados
BEFORE DELETE ON alumnos
FOR EACH ROW
BEGIN    
    INSERT INTO alumnos_borrados (id, nombre, apellido, edad, id_curso, fecha_borrado)
    VALUES (OLD.id, OLD.nombre, OLD.apellido, OLD.edad, OLD.id_curso, NOW());
END;

INSERT INTO alumnos(nombre, apellido, edad, id_curso)
VALUES
    ('UMMA', 'VERON', 24, 4),
    ('MARTINA', 'LAMAESTRE', 23, 4);
SELECT * FROM alumnos;

DELETE FROM alumnos WHERE id = 10;

SELECT * FROM alumnos_borrados;
