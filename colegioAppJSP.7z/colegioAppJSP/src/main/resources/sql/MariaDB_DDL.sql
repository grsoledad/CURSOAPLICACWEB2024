-- Active: 1733870745895@@127.0.0.1@3306@negocio
DROP DATABASE IF EXISTS colegio;

CREATE DATABASE colegio;

USE colegio;

DROP TABLE IF EXISTS alumnos;
DROP TABLE IF EXISTS cursos;
CREATE TABLE cursos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(50) NOT NULL, 
    profesor VARCHAR(50) NOT NULL,
    dia ENUM('LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES') NOT NULL,
    turno ENUM('MAÑANA', 'TARDE', 'NOCHE') NOT NULL
);

INSERT INTO cursos (titulo, profesor, dia, turno)
VALUES
    ('Programacion Web', 'Carlos Rios', 'LUNES', 'NOCHE'),
    ('HTML', 'Santi Saucedo', 'MIERCOLES', 'TARDE'),
    ('Base de Datos', 'Jorge Carrizo', 'JUEVES', 'NOCHE'),
    ('PHP', 'Alexis Cuevas', 'MARTES', 'MAÑANA'),
    ('Turismo', 'Leandro Caligaris', 'VIERNES', 'NOCHE');

CREATE TABLE alumnos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    edad INT NOT NULL CHECK (edad >= 18 AND edad <= 120),
    id_curso INT NOT NULL,
    FOREIGN KEY (id_curso) REFERENCES cursos(id)
);

INSERT INTO alumnos(nombre, apellido, edad, id_curso)
VALUES
    ('IGNACIO', 'FERRARI', 24, 1),
    ('SEBASTIAN', 'FERREYRA', 30, 3),
    ('LAURA', 'CHAVES', 22, 4),
    ('RODRIGO', 'IOCULANO', 33, 5),
    ('IVONNE', 'DESIRE', 20, 1),
    ('PABLO', 'ROMERO', 21, 4),
    ('FERNANDO', 'FRASCHINO', 21, 5),
    ('VALERIA', 'GARCIA', 27, 4);


SHOW TABLES;
SELECT * FROM cursos;
SELECT * FROM alumnos;


